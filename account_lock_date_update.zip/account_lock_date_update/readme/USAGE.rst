To use this module, you need to be a Billing Administrator and go to:

* Invoicing -> Accounting -> Actions -> Update accounting lock dates
* Change values and click on update button
