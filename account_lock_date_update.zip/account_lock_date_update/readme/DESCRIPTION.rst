Allow an Account adviser to update locking date without having
access to all technical settings.
